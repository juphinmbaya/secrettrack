"""
Secrets Track - Professional tool for detecting exposed secrets in code.
"""

__version__ = "1.0.0"
__author__ = "Juphin Mbaya"
__license__ = "MIT"