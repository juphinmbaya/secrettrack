import pytest
from pathlib import Path
from secrettrack.detectors.aws import AWSDetector
from secrettrack.detectors.github import GitHubDetector
from secrettrack.detectors.stripe import StripeDetector


class TestAWSDetector:
    def test_aws_access_key_detection(self):
        detector = AWSDetector()
        line = 'aws_access_key_id = "AKIAIOSFODNN7EXAMPLE"'
        results = detector.scan_line(line, 1, Path("test.py"))
        assert len(results) > 0
        assert results[0]["type"] == "aws"
        assert results[0]["severity"] in ["critical", "high", "medium", "low"]

    def test_aws_secret_key_detection(self):
        detector = AWSDetector()
        line = 'aws_secret_access_key = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"'
        results = detector.scan_line(line, 1, Path("test.py"))
        assert len(results) > 0


class TestGitHubDetector:
    def test_github_token_detection(self):
        detector = GitHubDetector()
        line = 'github_token = "ghp_abc123def456ghi789jkl012mno345pqr678stu"'
        results = detector.scan_line(line, 1, Path("test.py"))
        assert len(results) > 0
        assert results[0]["type"] == "github"


class TestStripeDetector:
    def test_stripe_live_key_detection(self):
        detector = StripeDetector()
        line = 'stripe_secret_key = "sk_live_abc123def456ghi789jkl012"'
        results = detector.scan_line(line, 1, Path("config/.env"))
        assert len(results) > 0
        assert results[0]["type"] == "stripe"
        assert results[0]["severity"] == "critical"

    def test_stripe_test_key_detection(self):
        detector = StripeDetector()
        line = 'stripe_test_key = "sk_test_abc123def456ghi789jkl012"'
        results = detector.scan_line(line, 1, Path("test.env"))
        assert len(results) > 0