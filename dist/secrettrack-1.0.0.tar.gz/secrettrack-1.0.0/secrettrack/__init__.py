"""
Secrets Hunter - Professional tool for detecting exposed secrets in code.
"""

__version__ = "1.0.0"
__author__ = "SecretsHunter Team"
__license__ = "MIT"